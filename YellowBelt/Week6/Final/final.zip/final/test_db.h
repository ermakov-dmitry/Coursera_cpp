//
// Created by dmitry on 06.01.2021.
//

#ifndef FINAL_TEST_DB_H
#define FINAL_TEST_DB_H

#pragma once
#include "database.h"
#include "date.h"

void TestAdd();
void TestFind();
void TestDel();
void TestLast();

#endif //FINAL_TEST_DB_H
